const ratio = wx.getSystemInfoSync().pixelRatio;
let screenWidth0 = wx.getSystemInfoSync().screenWidth * ratio;
let screenHeight0 = wx.getSystemInfoSync().screenHeight * ratio;

let screenWidth = 750;
let screenHeight = screenHeight0;

const itemWidth = 602,
  itemHeight = 104;
let itstartX = 74,
  itstartY = 216;
let headHeight = 64;
let iconR = 28;
let commonUrl = "Assets/Framework/";
const lvIcons = [
  "lv1.png",
  "lv2.png"
];
const cupurl = [
  "rankinglist1.png",
  "rankinglist2.png",
  "rankinglist3.png"
];

class Ranking {
  constructor() {
    this.sharedCanvas = wx.getSharedCanvas();
    this.context = this.sharedCanvas.getContext("2d");
    this.itemCanvas = wx.createCanvas();
    this.myIconCanvas = wx.createCanvas();
    this.myIconCanvas.width = iconR * 2;
    this.myIconCanvas.height = iconR * 2;
    this.ctx = this.itemCanvas.getContext("2d");
    this.title = "好友排行榜";
    this.myWinNum = undefined;
    this.myInfo = {};
    this.myRank = undefined;
    this.myLv = undefined;
    this.staticParts = null;
    this.isEmpty = false;
    this.drawBg();
    this.initUIInfo();
  }
  drawBg() {
    this.context.clearRect(0, 0, screenWidth, screenHeight);
    this.context.fillStyle = "#554D85";
    this.context.fillRect(0, 0, screenWidth, screenHeight);
  }
  init(res) {
    this.context.scale(screenWidth0 / screenWidth, screenWidth0 / screenWidth);
    this.context.clearRect(0, 0, screenWidth, screenHeight);
    this.getUserInfo();
    this.startListenMsg();
  }
  initUIInfo(noDraw) {
    let offsetX = 0,
      offsety = 0;
    this.staticParts = [
      {
        type: "Text",
        x: itstartX + 175,
        y: 134 - offsety,
        text: " 好友排行榜",
        fontSize: 32,
        name: "title",
        anchorX: 0.5
      },
      {
        type: noDraw ? "null" : "Text",
        x: itstartX,
        y: itstartY + headHeight + itemHeight * 7 + 23 * 2 - offsety,
        text: "每周一凌晨更新数据",
        fontSize: 20,
        color: "#e6e6e6",
        name: "updateTime"
      },
      {
        type: "Text",
        x: itstartX + itemWidth / 2 - 57,
        y: itstartY + headHeight + itemHeight * 7 + 23 * 2 + 196 - offsety,
        text: "标题",
        fontSize: 24,
        color: "#aeb3c1",
        name: "ksLb",
        anchorX: 0.5
      },
      {
        type: "Sprite",
        url: commonUrl + "rankingList/short_w.png",
        x: itstartX - 10 - offsetX,
        y: itstartY + headHeight + itemHeight * 7 + 102 - offsety,
        w: 240,
        h: 95,
        arc: 45,
        color: "#ffffff",
        name: "homeBtn",
        children: [
          {
            type: "Sprite",
            url: commonUrl + "rankingList/homeback.png",
            x: 70,
            y: 25,
            w: 40,
            h: 40
          },
          {
            type: "Text",
            x: 114,
            y: 28,
            text: "主页",
            fontSize: 28,
            color: "#9882ff",
            name: "labelTxt",
            padding: [3, 0, 3, 0]
          }
        ]
      },
      {
        type: "Sprite",
        url: commonUrl + "rankingList/p.png",
        x: itstartX - offsetX + 247,
        y: itstartY + headHeight + itemHeight * 7 + 102 - offsety,
        w: 365,
        h: 95,
        arc: 45,
        color: "#9882ff",
        name: "flockRankBtn",
        children: [
          {
            type: "Sprite",
            url: commonUrl + "rankingList/charts.png",
            x: 90,
            y: 25,
            w: 40,
            h: 40
          },
          {
            type: "Text",
            x: 134,
            y: 28,
            text: "查看群排行",
            fontSize: 28,
            name: "labelTxt",
            padding: [3, 0, 3, 0]
          }
        ]
      },
      {
        type: noDraw ? "null" : "ArcRect2",
        x: itstartX,
        y: itstartY - offsety,
        w: itemWidth,
        h: headHeight,
        arc: 8,
        color: "#9882ff",
        children: noDraw
          ? []
          : [
              {
                type: "Text",
                x: 28,
                y: 17,
                color: "#ffffff",
                text: "名次",
                padding: [2, 0, 2, 0],
                fontSize: 20
              },
              {
                type: "Text",
                x: 110,
                y: 17,
                color: "#ffffff",
                text: "好友",
                padding: [2, 0, 2, 0],
                fontSize: 20
              },
              {
                type: "Text",
                align: "right",
                x: 578,
                y: 17,
                color: "#ffffff",
                text: "本周胜利局数",
                padding: [2, 0, 2, 0],
                fontSize: 20
              }
            ]
      }
    ];
  }
  startListenMsg() {
    wx.onMessage(data => {
      if (data.e === "friends") {
        this.getFriendsRanking(data.gamePinyin, data.gameName);
      } else if (data.e === "group") {
        this.getGroupRanking(data.ticket, data.gamePinyin, data.gameName);
      } else if (data.e === "saveUserInfo") {
        this.myInfo = JSON.parse(data.info);
      } else if (data.e === "setRestPath") {
        // commonUrl=data.path+'/'
      } else if (data.e === "saveWinNum") {
        let gamePinyin = data.gamePinyin;
        wx.getUserCloudStorage({
          keyList: ["gamelv1"],
          success: res => {
            console.log(res);
            let newWinNum, newLv;
            let ob;
            if (res.KVDataList.length > 0) {
              ob = JSON.parse(res.KVDataList[0].value);
              if (!ob[gamePinyin]) ob[gamePinyin] = [0, 0];
              if (data.update) ob[gamePinyin][0] = ob[gamePinyin][0] + 1;
            } else {
              ob = {};
              if (data.update) ob[gamePinyin] = [1, 0];
              else ob[gamePinyin] = [0, 0];
            }
            if (data.lv) ob[gamePinyin][1] = data.lv;
            else if (!ob[gamePinyin][1]) ob[gamePinyin][1] = 0;
            console.log("get max win num:" + gamePinyin + ":" + newWinNum);
            wx.setUserCloudStorage({
              // KVDataList: [{ key: gameName, value: "" + newWinNum }, { key: gameName + "lv",value:""+newLv}],
              success: res => {
                console.log("save max win num succ:");
              },
              KVDataList: [{ key: "gamelv1", value: JSON.stringify(ob) }],
              fail: res => {
                console.log(
                  "save max win num succ:" + gameName + ":" + newWinNum
                );
              }
            });
          }
        });
      } else if (data.e === "clearItems") {
        this.context.clearRect(itstartX, 242, itemWidth, itemHeight * 6);
        this.context.fillStyle = "#f9f8ff";
        this.context.fillRect(itstartX, 242, itemWidth, itemHeight * 6); //  main
      } else if (data.e === "test") {
        console.log("tttttest");
      }
    });
    let startY = undefined,
      moveY = 0;
    wx.onTouchMove(e => {
      let touch = e.touches[0];
      // 触摸移动第一次触发的位置
      if (startY === undefined) {
        startY = touch.clientY + moveY;
      }
      moveY = startY - touch.clientY;
      if (!this.isEmpty) this.reDrawItem(moveY);
    });
    wx.onTouchEnd(e => {
      startY = undefined;
      if (moveY < 0) {
        // 到顶
        moveY = 0;
      } else if (moveY > this.itemCanvas.height - itemHeight * 6) {
        // 到底
        moveY = this.itemCanvas.height - itemHeight * 6;
      }
      if (!this.isEmpty) this.reDrawItem(moveY);
    });
  }
  getUserInfo() {
    wx.getUserInfo({
      openIdList: ["selfOpenId"],
      lang: "zh_CN",
      success: res => {
        this.myInfo = res.data[0];
      },
      fail: res => {}
    });
  }
  drawEmpty() {
    let empty = wx.createImage();
    empty.src = commonUrl + "rankingList/empty.png";
    empty.onload = function() {
      this.context.drawImage(empty, 207, 264);
    }.bind(this);
    this.context.font = "28px PingFangSC-Regular"; //排名
    this.context.textAlign = "center";
    this.context.fillStyle = "#ffffff";
    this.context.globalAlpha = 0.5;
    this.context.fillText("暂无好友排行", screenWidth / 2, 680);
    this.context.globalAlpha = 1;
    this.initUIInfo(true);
    this.staticParts[0].text = "" + this.title + " 好友排行榜";
    this.getUIs(this.staticParts, 0, 0);
  }
  initRanklist(list) {
    this.drawBg();
    if (list.length == 0) {
      this.isEmpty = true;
      this.drawEmpty();
      return;
    }
    let length = Math.max(list.length, 6);
    this.itemCanvas.width = itemWidth;
    this.itemCanvas.height = itemHeight * length;
    this.ctx.clearRect(0, 0, this.itemCanvas.width, this.itemCanvas.height);
    for (let i = 0; i < length; i++) {
      if (i % 2 === 0) {
        this.ctx.fillStyle = "#f9f8ff";
      } else {
        this.ctx.fillStyle = "#ffffff";
      }
      this.ctx.fillRect(0, i * itemHeight, this.itemCanvas.width, itemHeight);
    }

    if (list && list.length > 0) {
      list.map((item, index) => {
        let avatar = wx.createImage();
        avatar.src = item.avatarUrl;
        avatar.onload = function() {
          this.ctx.save();
          this.ctx.arc(
            99 + iconR,
            index * itemHeight + 18 + iconR + 5,
            iconR,
            0,
            Math.PI * 2
          );
          this.ctx.clip();
          this.ctx.drawImage(
            avatar,
            99,
            index * itemHeight + 18 + 5,
            iconR * 2,
            iconR * 2
          );
          this.ctx.restore();
          this.reDrawItem(0);
        }.bind(this);
        if (index < 3) {
          let cup = wx.createImage();
          cup.src = commonUrl + "rankingList/" + cupurl[index];
          cup.onload = function() {
            this.ctx.drawImage(cup, 24, index * itemHeight + 24, 50, 50);
            this.reDrawItem(0);
          }.bind(this);
        } else {
          this.ctx.font = "30px PingFangSC-Medium"; //排名
          this.ctx.textAlign = "center";
          this.ctx.fillStyle = "#a4a4a4";
          this.ctx.fillText(index + 1, 46, index * itemHeight + 64);
        }
        this.ctx.fillStyle = "#4a4a4a"; //昵称
        this.ctx.font = "28px PingFangSC-Light";
        this.ctx.textAlign = "left";
        let nickname = this.clamp(item.nickname, 6);
        this.ctx.fillText(nickname, 179, index * itemHeight + iconR * 2 + 5);
        if (item.lv > 0) {
          let lvicon = wx.createImage();
          lvicon.src = commonUrl + "Hall/" + lvIcons[item.lv - 1];
          lvicon.onload = function() {
            this.context.font = "28px PingFangSC-Light";
            this.ctx.drawImage(
              lvicon,
              178 + this.context.measureText(nickname).width + 15,
              index * itemHeight + 21,
              42,
              58
            );
            this.reDrawItem(0);
          }.bind(this);
        }

        this.ctx.font = "36px PingFangSC-Medium"; //胜利数
        this.ctx.textAlign = "right";
        this.ctx.fillStyle = index < 3 ? "#9882ff" : "#4a4a4a";
        this.ctx.fillText(
          item.winNum || 0,
          575,
          index * itemHeight + 60 + 5,
          72
        );
      });
    } else {
      // 没有数据
    }

    this.reDrawItem(0);
    this.initUIInfo();
    this.staticParts[0].text = "" + this.title + " 好友排行榜";
    this.getUIs(this.staticParts, 0, 0);
  }

  // 绘制自己的排名
  drawMyRank() {
    if (this.myInfo.avatarUrl!=undefined && this.myWinNum && this.myLv != undefined) {
      let myStartY = itstartY + headHeight + itemHeight * 6 + 23;
      this.getUI(
        {
          type: "ArcRect",
          w: itemWidth,
          h: itemHeight,
          x: itstartX,
          y: myStartY,
          arc: 8,
          color: "#ffffff"
        },
        0,
        0
      );
      let avatar = wx.createImage();
      avatar.src = this.myInfo.avatarUrl;
      avatar.onload = function() {
        let iconCtx = this.myIconCanvas.getContext("2d");
        iconCtx.arc(iconR, iconR, iconR, 0, Math.PI * 2);
        iconCtx.clip();
        iconCtx.drawImage(avatar, 0, 0, iconR * 2, iconR * 2);
        this.context.drawImage(
          this.myIconCanvas,
          0,
          0,
          this.myIconCanvas.width,
          this.myIconCanvas.height,
          99 + itstartX,
          myStartY + 18 + 5,
          iconR * 2,
          iconR * 2
        );
      }.bind(this);
      if (this.myRank < 3) {
        let cup = wx.createImage();
        cup.src = commonUrl + "rankingList/" + cupurl[this.myRank];
        cup.onload = function() {
          this.context.drawImage(cup, 24 + itstartX, myStartY + 24, 50, 50);
          // this.reDrawItem(0);
        }.bind(this);
      } else {
        this.context.font = "30px PingFangSC-Medium"; //排名
        this.context.textAlign = "center";
        this.context.fillStyle = "#a4a4a4";
        this.context.fillText(this.myRank + 1, 46 + itstartX, myStartY + 64);
      }

      let nickname = this.clamp(this.myInfo.nickName, 6);
      if (this.myLv > 0) {
        let lvicon = wx.createImage();
        lvicon.src = commonUrl + "Hall/" + lvIcons[this.myLv - 1];
        lvicon.onload = function() {
          this.context.font = "28px PingFangSC-Medium";
          this.context.drawImage(
            lvicon,
            185 + itstartX + this.context.measureText(nickname).width + 15,
            myStartY + 21,
            42,
            58
          );
          console.log(
            "drawMyRank:itStartx=" +
              itstartX +
              ", nickNameWidth=" +
              this.context.measureText(nickname).width
          );
          // this.reDrawItem(0);
        }.bind(this);
      }
      this.context.fillStyle = "#4a4a4a"; //昵称
      this.context.font = "28px PingFangSC-Medium";
      this.context.textAlign = "left";
      this.context.fillText(nickname, 185 + itstartX, myStartY + iconR * 2 + 5);
      this.context.font = "36px PingFangSC-Medium"; //胜利数
      this.context.textAlign = "right";
      this.context.fillStyle = this.myRank < 3 ? "#9882ff" : "#4a4a4a";
      this.context.fillText(
        this.myWinNum || 0,
        575 + itstartX,
        myStartY + 60 + 5,
        72
      );
    }
  }
  // 因为头像绘制异步的问题，需要重新绘制
  reDrawItem(y0) {
    this.context.clearRect(
      itstartX,
      itstartY + headHeight,
      itemWidth,
      itemHeight * 6
    );
    this.context.save();
    let w = itemWidth,
      h = itemHeight * 6,
      arc = 8,
      x = itstartX,
      y = itstartY + headHeight;
    this.context.fillStyle = "#ffffff";
    this.context.beginPath();
    this.context.moveTo(0, 0 + y);
    this.context.lineTo(w + x, 0 + y);
    this.context.lineTo(w + x, h - arc + y);
    this.context.arcTo(w + x, h + y, w - arc + x, h + y, arc);
    this.context.lineTo(arc + x, h + y);
    this.context.arcTo(0 + x, h + y, 0 + x, h - arc + y, arc);
    this.context.lineTo(0 + x, y);
    this.context.closePath();
    this.context.fill();
    this.context.clip();
    this.context.drawImage(
      this.itemCanvas,
      0,
      y0,
      itemWidth,
      itemHeight * 6,
      itstartX,
      itstartY + headHeight,
      itemWidth,
      itemHeight * 6
    );
    this.context.restore();
  }
  sortByWinNum(data, gamePinyin) {
    let array = [];
    data.map(item => {
      if (item.KVDataList.length > 0) {
        let d2 = JSON.parse(item.KVDataList[0].value)[gamePinyin];
        if (d2)
          array.push({
            avatarUrl: item.avatarUrl,
            nickname: item.nickname,
            openid: item.openid,
            winNum: d2[0],
            lv: d2[1]
          });
      }
    });
    array.sort((a, b) => {
      let anum = parseInt(a['winNum'])
      let bnum = parseInt(b['winNum'])
      if (anum > bnum) return -1;
      else if (anum == bnum) return 0
      else return 1;
    });
    this.myRank = array.findIndex(item => {
      return (
        item.nickname === this.myInfo.nickName &&
        item.avatarUrl === this.myInfo.avatarUrl
      );
    });
    if (this.myRank === -1) this.myRank = array.length;
    return array;
  }

  getFriendsRanking(gamePinyin, gameName) {
    wx.getFriendCloudStorage({
      keyList: ["gamelv1"],
      success: res => {
        let data = res.data;
        console.log(res.data);
        this.title = gameName;
        this.initRanklist(this.sortByWinNum(data, gamePinyin));
        this.getMyScore(gamePinyin);
      }
    });
  }

  getGroupRanking(ticket, gamePinyin, gameName) {
    wx.getGroupCloudStorage({
      shareTicket: ticket,
      // keyList: [gamePinyin, gamePinyin+"lv"],
      keyList: ["gamelv1"],
      success: res => {
        console.log("getGroupCloudStorage:success");
        console.log(res.data);
        let data = res.data;
        this.title = gameName;
        this.initRanklist(this.sortByWinNum(data, gamePinyin));
        this.getMyScore(gamePinyin);
      },
      fail: res => {
        console.log(res.data);
      }
    });
  }

  getMyScore(gamePinyin) {
    if (this.isEmpty) return;
    wx.getUserCloudStorage({
      keyList: ["gamelv1"],
      success: res => {
        let ob;
        if (res.KVDataList.length > 0) {
          ob = JSON.parse(res.KVDataList[0].value);
        } else {
        }
        if (ob && ob[gamePinyin]) {
          this.myWinNum = ob[gamePinyin][0] || 0;
          this.myLv = ob[gamePinyin][1] || 0;
        } else {
          this.myWinNum = undefined;
        }
        this.drawMyRank(gamePinyin);
      }
    });
  }
  getUI(params, startx, starty) {
    var type = params.type;
    var sp;
    let x = params.x + startx,
      y = params.y + starty;
    var txt = this.context.measureText(params.text);
    if (type == "Text") {
      if (params.padding) txt.padding = params.padding;
      this.context.textAlign = "left";
      if (params.anchorX) {
        this.context.textAlign = "center";
        x = screenWidth / 2;
      }

      this.context.fillStyle = params.color || "#ffffff";
      this.context.font = "" + (params.fontSize || 20) + "px PingFangSC-Medium";
      if (params.align) this.context.textAlign = params.align;
      this.context.fillText(params.text, x, y + params.fontSize + 1);
    } else if (type == "ArcRect" || type == "Button") {
      let w = params.w,
        h = params.h,
        arc = params.arc;
      if (params.anchorX) x = x - w * params.anchorX;
      if (params.anchorY) y = y - h * params.anchorY;
      this.context.fillStyle = params.color;
      this.context.beginPath();
      this.context.moveTo(arc + x, 0 + y);
      this.context.lineTo(w - arc + x, 0 + y);
      this.context.arcTo(w + x, 0 + y, w + x, arc + y, arc);
      this.context.lineTo(w + x, h - arc + y);
      this.context.arcTo(w + x, h + y, w - arc + x, h + y, arc);
      this.context.lineTo(arc + x, h + y);
      this.context.arcTo(0 + x, h + y, 0 + x, h - arc + y, arc);
      this.context.lineTo(0 + x, arc + y);
      this.context.arcTo(0 + x, 0 + y, arc + x, 0 + y, arc);
      this.context.closePath();
      this.context.fill();
    } else if (type == "ArcRect2") {
      let w = params.w,
        h = params.h,
        arc = params.arc;
      this.context.fillStyle = params.color;
      this.context.beginPath();
      this.context.moveTo(arc + x, 0 + y);
      this.context.lineTo(w - arc + x, 0 + y);
      this.context.arcTo(w + x, 0 + y, w + x, arc + y, arc);
      this.context.lineTo(w + x, h + y);
      this.context.lineTo(x, h + y);
      this.context.lineTo(0 + x, arc + y);
      this.context.arcTo(0 + x, 0 + y, arc + x, 0 + y, arc);
      this.context.closePath();
      this.context.fill();
    } else if (type == "Sprite") {
      let sp = wx.createImage();
      sp.src = params.url;
      sp.onload = function() {
        this.context.drawImage(
          sp,
          0,
          0,
          sp.width,
          sp.height,
          x,
          y,
          params.w,
          params.h
        );
        if (params.children) {
          this.getUIs(params.children, x, y);
        }
      }.bind(this);
    }
    if (sp) {
      if (params.w) sp.width = params.w;
      if (params.h) sp.height = params.h;
      if (params.scaleX) sp.scaleX = params.scaleX;
      if (params.scaleY) sp.scaleY = params.scaleY;
      sp.name = params.name;
    }
    if (params.children && type != "Sprite") {
      this.getUIs(params.children, x, y);
    }
  }
  getUIs(obs, startx, starty) {
    for (let i = 0; i < obs.length; i++) {
      if (!obs[i].name) obs[i].name = "child_" + i;
      this.getUI(obs[i], startx, starty);
    }
  }

  clamp(str, n) {
    if (!str) {
      return "...";
    }
    if (str.length <= n) {
      return str;
    }
    let resStr = "";
    for (let i = 0; i < n; i++) {
      if (str[i]) {
        resStr = resStr + str[i];
      } else {
        break;
      }
    }
    resStr = resStr + "...";
    return resStr;
  }
}
export default new Ranking();
