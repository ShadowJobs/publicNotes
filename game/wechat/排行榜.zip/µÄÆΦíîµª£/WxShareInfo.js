import GameManager from "./GameManager";
import WebGlDraw from "./webDraw";
import Notification from "./Notification";

const ratio = wx.getSystemInfoSync().pixelRatio;
const screenWidth = window.innerWidth * ratio;
const screenHeight = window.innerHeight * ratio;
class WxShareInfo {
  constructor() {
    this.sharedContext = null;
    this.sharedCanvas = null;
    this.mainContext = null;
    this.eventStopLayer = null;
    this.sharedCanvasInited = false;
    this.hitBtn = 0;
    this.isIos = false;
    this.useWebgl = true;
    this.openGlProgram = null;
    this.glTexture = null;
    this.vertextSizeBuffer = null;
  }
  initCanvas() {
    this.sharedContext = wx.getOpenDataContext();
    this.sharedCanvas = this.sharedContext.canvas;
    if (this.useWebgl) {
      WebGlDraw.init();
    } else this.mainContext = canvas.getContext("2d");
    if (this.isIos) {
      //ios下微信官方提供的webgl绘制方式,经测试无效
      this.mainContext = canvas.getContext("webgl");
      this.mainContext.wxBindCanvasTexture(this.mainContext.TEXTURE_2D, this.sharedContext);
    }
    this.eventStopLayer = new Laya.Sprite();
    this.eventStopLayer.visible = false;
    GameManager.eventStopLayer = this.eventStopLayer;
    wx.showShareMenu({
      withShareTicket: true,
    });

    wx.onShow(
      function(info) {
        this.startCheck(info);
      }.bind(this),
    );
    this.initShowSharedCanvas();
  }
  startCheck(info) {
    let resPath = wx.getStorageSync(`game_common_resource`);
    if (resPath && resPath.path) {
      this.sharedContext.postMessage({
        e: "setRestPath",
        path: resPath.path,
      });
    }
    var ticket;
    if (info.scene == 1044) {
      ticket = info.shareTicket;
      console.log("shareTicket:" + ticket);
    }
    if (false) this.testFriends();
    if (info.query) {
      if (info.query.from == "ranking" && ticket) {
        this.eventStopLayer.visible = true;
        GameManager.lastShareGame = {
          gameName: info.query.gameName,
          gamePinyin: info.query.gamePinyin,
          gId: info.query.gId,
        };
        this.sharedContext.postMessage({
          e: "group",
          ticket: ticket,
          gameName: info.query.gameName,
          gamePinyin: info.query.gamePinyin,
        });
        // setTimeout(() => {
        GameManager.needOpenRank = true;
        GameManager.ranking = true;
        // },150)
      } else if (info.query.from == "menu") {
      }
    }
    console.log("aaaa");
    console.log(info);
    console.log(wx.getLaunchOptionsSync());
    // let appId = (info.referrerInfo && info.referrerInfo.appId) || (info.query && info.query.appId);
    // appId = null;
    // if (appId) {
    //   GameManager.fromApp = appId;
    //   let roomId=(info.query && info.query.roomId) || "374637"
    //   Notification.post("startFromMiniProgram", { appId: appId, roomId: roomId, otherPlayer: { name: "秀的飞起", avatarUrl:"www.baidu.com"} });
    //   // Notification.post("startFromMiniProgram", { });
    // }
    // // if (info.referrerInfo) {
    // //   //scene=1037或1038时支持
    // //   Notification.post("startFromMiniProgram", { data:info.referrerInfo.extraData});
    // // }
    // // else if (info.query.appId)
    // // {
    // //   Notification.post("startFromMiniProgram", { data: info.query.appId });
    // // }
    // else {
    //   Notification.post("startFromMiniProgram", {});
    // }
  }
  refreshCanvas() {
    ////方法一 用微信原生支持
    if (this.useWebgl) {
      WebGlDraw.drawLoop();
    } else this.mainContext.drawImage(this.sharedCanvas, 0, 0, screenWidth, screenHeight);
    if (!this.isIos) {
      //安卓下的方法
    }
    //方法2 用laya只给bitmap赋值更新
    //  shareTexture = new Laya.Texture(Laya.Browser.window.sharedCanvas)
    // shareTexture.fillTexture(new Laya.Texture(Laya.Browser.window.sharedCanvas))
    // shareTexture. bitmap.alwaysChange=false
    // shareTexture.bitmap = Laya.Browser.window.sharedCanvas
    // sharedSp.graphics.clear()
    // sharedSp.graphics.destroy()
    // sharedSp.graphics=new Laya.Graphics()
    // sharedSp.graphics.fillTexture(new Laya.Texture(Laya.Browser.window.sharedCanvas))
    // sharedSp.graphics.clear()
    // sharedSp.graphics.drawTexture(shareTexture)
    // // sharedSp.graphics.cleanByTexture(shareTexture,0,0)
    // shareTexture.destroy(true)
    // shareTexture=null
    // wx.triggerGC()
  }
  testFriends() {
    GameManager.needOpenRank = true;
    GameManager.ranking = true;
    this.eventStopLayer.visible = true;
    GameManager.lastShareGame = {
      gameName: "五子棋",
      gamePinyin: "wuziqi",
      gId: "1",
    };
    setTimeout(() => {
      this.sharedContext.postMessage({
        e: "friends",
        gameName: "五子棋",
        gamePinyin: "wuziqi",
      });
    }, 30);
  }
  loop() {
    if (GameManager.needOpenRank) {
      GameManager.needOpenRank = false;
      this.initShare();
    }
    if (GameManager.ranking) this.refreshCanvas();
    requestAnimationFrame(this.loop.bind(this));
  }
  checkHit(e, btn) {
    let rect;
    // let scale = screenWidth/750
    let scale = 1;
    if (btn == "home") rect = { x: 64, y: 964, w: 230, h: 90 };
    else if (btn == "rank") rect = { x: 278, y: 964, w: 298, h: 78 };
    else if (btn == "list") rect = { x: 64, y: 242, w: 512, h: 552 };
    if (
      e.currentTarget.mouseX > rect.x * scale &&
      e.currentTarget.mouseX < (rect.x + rect.w) * scale &&
      e.currentTarget.mouseY > rect.y * scale &&
      e.currentTarget.mouseY < (rect.y + rect.h) * scale
    ) {
      console.log("hit" + btn);
      return true;
    }
    return false;
  }
  initShowSharedCanvas() {
    this.eventStopLayer.graphics.drawRect(0, 0, Laya.stage.width, screenHeight, "#000000");
    this.eventStopLayer.size(Laya.stage.width, screenHeight);
    this.eventStopLayer.alpha = 0;
    this.eventStopLayer.mouseEnabled = true;
    this.eventStopLayer.mouseThrough = false;
    this.eventStopLayer.on(Laya.Event.MOUSE_DOWN, null, e => {
      if (this.checkHit(e, "home")) {
        this.hitBtn = 1;
      } else if (this.checkHit(e, "rank")) {
        this.hitBtn = 2;
      }
      e.stopPropagation();
    });
    this.eventStopLayer.on(Laya.Event.MOUSE_UP, null, e => {
      e.stopPropagation();
      if (this.checkHit(e, "home") && this.hitBtn == 1) {
        GameManager.ranking = false;
        this.eventStopLayer.visible = false;
        if (this.useWebgl) {
          WebGlDraw.resetY();
          Laya.stage.visible = true;
          this.sharedContext.postMessage({ e: "clearItems" });
        }
      } else if (this.checkHit(e, "rank") && this.hitBtn == 2) {
        GameManager.shareToWx(
          "你在群里排第几名？",
          "http://bbb.png",
          GameManager.lastShareGame.gameName,
          GameManager.lastShareGame.gamePinyin,
          GameManager.lastShareGame.gId,
          "ranking",
        );
      }
      this.hitBtn = 0;
    });
    this.eventStopLayer.zOrder = 10001;
    Laya.stage.addChild(this.eventStopLayer);
    this.eventStopLayer.visible = false;
    requestAnimationFrame(this.loop.bind(this));
  }
  initShare() {
    if (this.sharedCanvasInited) return;
    this.sharedCanvasInited = true;
    let openDataContext = wx.getOpenDataContext();
    let sharedCanvas = openDataContext.canvas;
    sharedCanvas.width = screenWidth;
    sharedCanvas.height = screenHeight;
  }
}
export default new WxShareInfo();
