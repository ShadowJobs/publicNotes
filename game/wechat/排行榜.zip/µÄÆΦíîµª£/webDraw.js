const ratio = wx.getSystemInfoSync().pixelRatio;
const screenWidth = window.innerWidth * ratio;
const screenHeight = window.innerHeight * ratio;
class WebGlDraw{
  constructor(){
    this.gl=null
    this.texture=null
    this.openDataProgram=null
    this.vertexSizeBuffer=null
    this.verticesSizes = new Float32Array([
      -1, 1, 0.0, 1.0,
      -1, -1, 0.0, 0.0,
      1, 1, 1.0, 1.0,
      1, -1, 1.0, 0.0
    ]);
  }
  init(){
    var openDataContext = wx.getOpenDataContext();
    this.sharedCanvas = openDataContext.canvas;
    // this.sharedCanvas.width = screenWidth;
    // this.sharedCanvas.height = screenHeight;
    // this.sharedCanvas.scale(screenWidth/750,screenHeight/1136)
    // this.gl = canvas.getContext('webgl')////ios
    this.gl=Laya.WebGL.mainContext
    this.texture = this.gl.createTexture();
    this.vertexSizeBuffer = this.gl.createBuffer();
    this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.vertexSizeBuffer)
    this.gl.bufferData(this.gl.ARRAY_BUFFER, this.verticesSizes, this.gl.STATIC_DRAW);
    this.gl.bindBuffer(this.gl.ARRAY_BUFFER, null)
    if (!this.initShaders()) { return; }
  }
  initShaders() {
    var VSHADER_SOURCE = `
      attribute vec4 a_Position;
      attribute vec2 a_TexCoord;
      varying vec2 v_TexCoord;
      void main(){
        gl_Position = a_Position;
        v_TexCoord = a_TexCoord;
      }`;
    var FSHADER_SOURCE = `
      precision mediump float;
      uniform sampler2D u_Sampler;
      varying vec2 v_TexCoord;
      void main(){
        gl_FragColor = texture2D(u_Sampler,v_TexCoord);
      }`;
    var program = this.createProgram( VSHADER_SOURCE, FSHADER_SOURCE);
    if (!program) {
      console.log('无法创建程序对象');
      return false;
    }
    this.openDataProgram = program
    return true;
  };

  createProgram( vshader, fshader) {
    var vertexShader = this.loadShader( this.gl.VERTEX_SHADER, vshader);
    var fragmentShader = this.loadShader( this.gl.FRAGMENT_SHADER, fshader);
    if (!vertexShader || !fragmentShader) {
      return null;
    }
    var program = this.gl.createProgram();
    if (!program) {
      return null;
    }
    this.gl.attachShader(program, vertexShader);
    this.gl.attachShader(program, fragmentShader);
    this.gl.linkProgram(program);
    var linked = this.gl.getProgramParameter(program, this.gl.LINK_STATUS);
    if (!linked) {
      var error = this.gl.getProgramInfoLog(program);
      console.log('无法连接程序对象: ' + error);
      this.gl.deleteProgram(program);
      this.gl.deleteShader(fragmentShader);
      this.gl.deleteShader(vertexShader);
      return null;
    }
    return program;
  };

  loadShader( type, source) {
    var shader = this.gl.createShader(type);
    if (shader == null) {
      return null;
    }
    this.gl.shaderSource(shader, source);
    this.gl.compileShader(shader);
    var compiled = this.gl.getShaderParameter(shader, this.gl.COMPILE_STATUS);
    if (!compiled) {
      var error = this.gl.getShaderInfoLog(shader);
      console.log('Failed to compile shader: ' + error);
      this.gl.deleteShader(shader);
      return null;
    }
    return shader;
  };
  drawLoop(){
    Laya.stage.visible = false;
    this.gl.useProgram(this.openDataProgram);
    this.gl.program = this.openDataProgram;
    var n = this.initVertexBuffers();
    if (n < 0) { return; }
    this.initTextures(n)
  }

  initVertexBuffers() {
    var n = 4;
    if (!this.vertexSizeBuffer) {
      console.log("无法创建缓冲区");
      return -1;
    }
    this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.vertexSizeBuffer);
    var a_Position = this.gl.getAttribLocation(this.gl.program, "a_Position");
    if (a_Position < 0) {
      console.log("无法获取到存储位置");
      return;
    }
    var fsize = this.verticesSizes.BYTES_PER_ELEMENT;
    this.gl.vertexAttribPointer(a_Position, 2, this.gl.FLOAT, false, fsize * 4, 0);
    this.gl.enableVertexAttribArray(a_Position);
    var a_TexCoord = this.gl.getAttribLocation(this.gl.program, "a_TexCoord");
    if (a_TexCoord < 0) {
      console.log("无法获取到存储位置");
      return;
    }
    this.gl.vertexAttribPointer(a_TexCoord, 2, this.gl.FLOAT, false, fsize * 4, fsize * 2);
    this.gl.enableVertexAttribArray(a_TexCoord);
    return n;
  };

  initTextures(n) {
    if (!this.texture) {
      console.log("无法创建纹理对象");
      return;
    }
    var u_Sampler = this.gl.getUniformLocation(this.gl.program, "u_Sampler");
    if (u_Sampler < 0) {
      console.log("无法获取变量的存储位置");
      return;
    }
    let oldUFYWv = this.gl.getParameter(this.gl.UNPACK_FLIP_Y_WEBGL) 
    this.gl.pixelStorei(this.gl.UNPACK_FLIP_Y_WEBGL, 1);
    this.gl.activeTexture(this.gl.TEXTURE0);
    this.gl.bindTexture(this.gl.TEXTURE_2D, this.texture);
    // this.gl.generateMipmap(this.gl.TEXTURE_2D);
    this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_WRAP_S, this.gl.CLAMP_TO_EDGE);
    this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_WRAP_T, this.gl.CLAMP_TO_EDGE);
    this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_MIN_FILTER, this.gl.LINEAR);
    this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_MAG_FILTER, this.gl.LINEAR);
    this.gl.texImage2D(this.gl.TEXTURE_2D, 0, this.gl.RGB, this.gl.RGB, this.gl.UNSIGNED_BYTE, this.sharedCanvas);
    this.gl.uniform1i(u_Sampler, 0);
    this.gl.clearColor(0.332, 0.3007, 0.52, 1.0);
    this.gl.clear(this.gl.COLOR_BUFFER_BIT);
    this.gl.drawArrays(this.gl.TRIANGLE_STRIP, 0, n);
    this.gl.pixelStorei(this.gl.UNPACK_FLIP_Y_WEBGL, oldUFYWv?1:0);
    // this.gl.bindTexture(this.gl.TEXTURE_2D,null)
    // this.gl.bindBuffer(this.gl.ARRAY_BUFFER,null)
    // this.gl.deleteTexture(1,this.texture)
    // this.gl.deleteBuffer(this.vertexSizeBuffer)
  };

  resetY() {
    Laya.Buffer._bindActive[this.gl.ARRAY_BUFFER]=null
    // this.gl.bindBuffer(this.gl.ARRAY_BUFFER, null)
    // this.gl.deleteBuffer(this.vertexSizeBuffer)
    // laya.webgl.canvas.WebGLContext2D.clear()
    // Laya.stage._loop()
  }
}
export default new WebGlDraw()